package com.narin.cns

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class CnsApplicationTests {

	@Test
	fun contextLoads() {
	}

}
